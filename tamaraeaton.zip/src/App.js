import React from 'react';
import './App.css';
import TVShowQuery from './components/TVShowQuery/TVShowQuery';

function App() {
  return (
    <div className="App">
      <TVShowQuery />
    </div>
  );
}

export default App;
